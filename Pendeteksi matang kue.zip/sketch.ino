
#include <Wire.h>
#include <LiquidCrystal_I2C.h>
#include <DHT.h>

#define DHTPIN 4
#define DHTTYPE DHT22

#define LED_MERAH 18
#define LED_KUNING 19
#define LED_HIJAU 23

DHT dht(DHTPIN, DHTTYPE);

LiquidCrystal_I2C lcd(0x27, 16, 2);

void setup() {
  Serial.begin(115200);

  dht.begin();

  Wire.begin(21, 22);
  lcd.init();
  lcd.backlight();

  pinMode(LED_MERAH, OUTPUT);
  pinMode(LED_KUNING, OUTPUT);
  pinMode(LED_HIJAU, OUTPUT);

  lcd.setCursor(0, 0);
  lcd.print("DETEKSI KUE");
  lcd.setCursor(0, 1);
  lcd.print("ESP32 READY");
  delay(2000);
}

void loop() {
  float suhu = dht.readTemperature();

  if (isnan(suhu)) {
    lcd.clear();
    lcd.print("Sensor Error");
    delay(2000);
    return;
  }

  digitalWrite(LED_MERAH, LOW);
  digitalWrite(LED_KUNING, LOW);
  digitalWrite(LED_HIJAU, LOW);

  lcd.clear();
  lcd.setCursor(0, 0);
  lcd.print("Suhu: ");
  lcd.print(suhu, 1);
  lcd.print(" C");

  lcd.setCursor(0, 1);

  if (suhu < 30) {
    lcd.print("Belum Matang");
    digitalWrite(LED_MERAH, HIGH);
  }
  else if (suhu < 35) {
    lcd.print("Hampir Matang");
    digitalWrite(LED_KUNING, HIGH);
  }
  else {
    lcd.print("Sudah Matang");
    digitalWrite(LED_HIJAU, HIGH);
  }

  Serial.print("Suhu: ");
  Serial.print(suhu);
  Serial.println(" C");

  delay(2000);
}
