int merah = 32;
int kuning = 35;
int hijau = 34;

int merah2 = 25;
int kuning2 = 33;
int hijau2 = 26;

int merah3 = 0;
int kuning3 = 2;
int hijau3 = 15;

int merah4 = 23;
int kuning4 = 22;
int hijau4 = 21;

void setup() {
  pinMode(merah, OUTPUT);
  pinMode(kuning, OUTPUT);
  pinMode(hijau, OUTPUT);

  pinMode(merah2, OUTPUT);
  pinMode(kuning2, OUTPUT);
  pinMode(hijau2, OUTPUT);

  pinMode(merah3, OUTPUT);
  pinMode(kuning3, OUTPUT);
  pinMode(hijau3, OUTPUT);

  pinMode(merah4, OUTPUT);
  pinMode(kuning4, OUTPUT);
  pinMode(hijau4, OUTPUT);
}

void semuaMerah() {
  digitalWrite(merah, HIGH);
  digitalWrite(merah2, HIGH);
  digitalWrite(merah3, HIGH);
  digitalWrite(merah4, HIGH);

  digitalWrite(kuning, LOW);
  digitalWrite(kuning2, LOW);
  digitalWrite(kuning3, LOW);
  digitalWrite(kuning4, LOW);

  digitalWrite(hijau, LOW);
  digitalWrite(hijau2, LOW);
  digitalWrite(hijau3, LOW);
  digitalWrite(hijau4, LOW);

}

void loop() {
  semuaMerah();
  digitalWrite(merah,LOW);
  digitalWrite(hijau,HIGH);
  delay(5000);

  digitalWrite(hijau,HIGH);
  digitalWrite(kuning,LOW);
  delay(2000);

  semuaMerah();
  digitalWrite(merah2,LOW);
  digitalWrite(hijau2,HIGH);
  delay(5000);

  digitalWrite(hijau2,HIGH);
  digitalWrite(kuning2,LOW);
  delay(2000);

  semuaMerah();
  digitalWrite(merah3,LOW);
  digitalWrite(hijau3,HIGH);
  delay(5000);

  digitalWrite(hijau3,HIGH);
  digitalWrite(kuning3,LOW);
  delay(2000);

  semuaMerah();
  digitalWrite(merah4,LOW);
  digitalWrite(hijau4,HIGH);
  delay(5000);

  digitalWrite(hijau4,HIGH);
  digitalWrite(kuning4,LOW);
  delay(2000);
}