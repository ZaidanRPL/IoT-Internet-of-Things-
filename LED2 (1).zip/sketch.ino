const int lampu = 33;
const int lampu2 = 25;
const int lampu3 = 26;
void setup(){
  pinMode(lampu, OUTPUT);
  pinMode(lampu2, OUTPUT);
  pinMode(lampu3, OUTPUT);
}
void loop(){
  digitalWrite(lampu, HIGH);
  digitalWrite(lampu2, LOW);
  digitalWrite(lampu3, LOW);
  delay(1000);

  digitalWrite(lampu, LOW);
  digitalWrite(lampu2, HIGH);
  digitalWrite(lampu3, LOW);
  delay(1000);

  digitalWrite(lampu, LOW); 
  digitalWrite(lampu2, LOW);
  digitalWrite(lampu3, HIGH);
  delay(1000);
}